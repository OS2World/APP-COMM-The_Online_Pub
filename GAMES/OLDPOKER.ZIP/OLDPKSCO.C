#include "top.h"

void poker_findwinners(char *wwho, poker_game_typ *wgame)
{
unsigned XINT *handscores, maxscore = 0;
unsigned long *handrawscores, maxrawscore = 0;
XINT fwd, winnum = 0;
poker_player_typ wplyr;

handscores = farcalloc(MAXNODES, 2);
if (!handscores)
    {
    dispatch_message(MSG_GENERIC, "^I^mNot enough memory to play Poker!^A^p",
                     od_control.od_node, 0, 0);
    return;
    }
handrawscores = farcalloc(MAXNODES, 4);
if (!handrawscores)
    {
    dispatch_message(MSG_GENERIC, "^I^mNot enough memory to play Poker!^A^p",
                     od_control.od_node, 0, 0);
    dofree(handscores);
    return;
    }

memset(wgame->winners, -1, 10);

for (fwd = 0; fwd < MAXNODES; fwd++)
	{
    if (!wwho[fwd])
    	{
        continue;
        }
    poker_loadplyrdata(fwd, &wplyr);
    handscores[fwd] = poker_scorehand(&wplyr);
    handrawscores[fwd] = poker_rawscorehand(&wplyr);
    if (handscores[fwd] > maxscore)
    	{
        maxscore = handscores[fwd];
        maxrawscore = handrawscores[fwd];
        memcpy(wgame->wincards, wplyr.cards, 10L);
        }
    if (handscores[fwd] == maxscore && handrawscores[fwd] > maxrawscore)
    	{
        maxrawscore = handrawscores[fwd];
        memcpy(wgame->wincards, wplyr.cards, 10L);
        }
    }

for (fwd = 0; fwd < 10; fwd++)
	{
    wgame->winners[fwd] = -1;
    }
for (fwd = 0; fwd < MAXNODES; fwd++)
	{
    if (handscores[fwd] == maxscore && handrawscores[fwd] == maxrawscore)
    	{
        wgame->winners[winnum++] = fwd;
        }
    }

wgame->winscore = maxscore;
wgame->winrawscore = maxrawscore;
wgame->numwinners = winnum;

dofree(handscores); dofree(handrawscores);

return;
}

#define scard       sdat->cards
#define ssuit(xss)  (sdat->cards[xss] % 4)
#define acemod(amv) (((sdat->cards[amv] % 13) == 0) ? (sgame.acehigh\
					 ? 13 : 0) : 0)
#define sval(xsv)   ((sdat->cards[xsv] % 13) + acemod(xsv))

unsigned XINT poker_scorehand(poker_player_typ *sdat)
{
unsigned XINT scoreret, sd, se;
char basehand[3] = { 0,0,0 }, pairvals[10], pnum;
poker_game_typ sgame;

poker_loadgamedata(&sgame);

poker_sorthand(sdat);

// Major mods for 7Stud, naturally.
// Ditto for Jokers.

for (sd = 0, pnum = 0; sd < 5; sd++)
	{
    for (se = sd + 1; se < 5; se++)
		{
		if (sval(sd) == sval(se))
			{
            basehand[0]++;
            pairvals[pnum++] = sval(se);
            }
        }
    }

scoreret = POKHAND_HIGHCARD + sval(4);
if (basehand[0] == 1)
	{
    scoreret = POKHAND_ONEPAIR + pairvals[0];
    }
if (basehand[0] == 2)
	{
    scoreret = POKHAND_TWOPAIR + (pairvals[1] * 0x10) + pairvals[0];
    }
if (basehand[0] == 3)
	{
    scoreret = POKHAND_THREEKIND + pairvals[2];
    }
if ((sval(1) == sval(0) + 1) && (sval(2) == sval(0) + 2) &&
	(sval(3) == sval(0) + 3) && (sval(4) == sval(0) + 4))
    {
    basehand[1]++;
    scoreret = POKHAND_STRAIGHT + sval(4);
    }
if ((ssuit(0) == ssuit(1)) && (ssuit(1) == ssuit(2)) &&
	(ssuit(2) == ssuit(3)) && (ssuit(3) == ssuit(4)))
	{
    basehand[2]++;
    scoreret = POKHAND_FLUSH + sval(4);
    }
if (basehand[0] == 4)
	{
    if (sval(1) == sval(2))
    	{
        scoreret = POKHAND_FULLHOUSE + (sval(2) * 0x10) + sval(3);
        }
    else
    	{
        scoreret = POKHAND_FULLHOUSE + (sval(2) * 0x10) + sval(1);
        }
    }
if (basehand[0] == 6)
	{
    scoreret = POKHAND_FOURKIND + pairvals[5];
    }
if (basehand[1] == 1 && basehand[2] == 1)
	{
    scoreret = POKHAND_STRAIGHTFLUSH + sval(4);
    }

return scoreret;
}

unsigned long poker_rawscorehand(poker_player_typ *sdat)
{
XINT prshd;
unsigned long scoreret = 0;
poker_game_typ sgame;

poker_loadgamedata(&sgame);

for (prshd = 0; prshd < 5; prshd++)
	{
	scoreret += ((unsigned long) sval(prshd) +
			    ((unsigned long) 0x10 * (unsigned long) prshd));
	}

//scoreret <<= 8L; // Should only be done for 5 card games!
//scoreret <<= 4L; (6 card games)

return scoreret;
}

void poker_sorthand(poker_player_typ *sdat)
{
char tmpsort[10] = { 0,0,0,0,0,0,0,0,0,0 };
char sortused[10] = { 0,0,0,0,0,0,0,0,0,0 };
unsigned XINT highcardval;
XINT sort1, sort2;
char highcardnum;
poker_game_typ sgame;

poker_loadgamedata(&sgame);

for (sort1 = 4; sort1 >= 0; sort1--) // 4 = numcards - 1
	{
    highcardval = 0;
    highcardnum = -1;
    for (sort2 = 0; sort2 < 5; sort2++)
    	{
        if (!sortused[sort2])
        	{
            unsigned XINT tmpval;

            tmpval = (sval(sort2) * 0x10) + ssuit(sort2);
            if (tmpval >= highcardval)
            	{
                highcardval = tmpval;
                highcardnum = sort2;
                }
            }
        }
    sortused[highcardnum] = 1;
    tmpsort[sort1] = sdat->cards[highcardnum];
    }

memcpy(sdat->cards, tmpsort, 10);

return;
}
