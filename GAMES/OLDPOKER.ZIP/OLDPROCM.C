#include "top.h"

XINT process_messages(char delname)
{
XINT d, proc = 0, mused = 0, isaction = 0, res, dn;
msg_typ msgin;
char filnam[256], ttt[10], tstbit[2];
unsigned char allowbits = 0;
unsigned long cdc;
struct ffblk mchg;
poker_game_typ mgame;
poker_player_typ mplyr;
char pokerstack[100], pokcount = 0;
XINT pokstacknode[100];

memset(pokerstack, 0, 100); pokcount = 0;
for (d = 0; d < 100; d++)
    {
    pokstacknode[d] = -1;
    }

lseek(chgfil, (od_control.od_node), SEEK_SET);
rec_locking(REC_LOCK, chgfil, (od_control.od_node), 1L);
read(chgfil, tstbit, 1L);
rec_locking(REC_UNLOCK, chgfil, (od_control.od_node), 1L);

if (!tstbit[0])
	{
    return 0;
    }

tstbit[0] = 0;
lseek(chgfil, (od_control.od_node), SEEK_SET);
rec_locking(REC_LOCK, chgfil, (od_control.od_node), 1L);
write(chgfil, tstbit, 1L);
rec_locking(REC_UNLOCK, chgfil, (od_control.od_node), 1L);

for (d = 0, dn = delname; d < filelength(midxinfil); d++)
	{
    res = lseek(midxinfil, (long) d, SEEK_SET);
    if (res == -1)
    	{
        continue;
        }
    rec_locking(REC_LOCK, midxinfil, d, 1L);
    res = read(midxinfil, tstbit, 1L);
    if (res == -1)
    	{
	    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
        continue;
        }
	// This needs changing to a large, malloc()ed, buffered array to
    // improve speed
    if (!tstbit[0])
    	{
	    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
        continue;
        }
    res = lseek(msginfil, (long) d * (long) sizeof(msg_typ), SEEK_SET);
    if (res == -1)
    	{
	    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
        continue;
        }
    rec_locking(REC_LOCK, msginfil, (long) d * (long) sizeof(msg_typ),
    			(long) sizeof(msg_typ));
    res = read(msginfil, &msgin, sizeof(msg_typ));
    rec_locking(REC_UNLOCK, msginfil, (long) d * (long) sizeof(msg_typ),
    			(long) sizeof(msg_typ));
    if (res == -1)
    	{
	    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
        continue;
        }

    if (msgin.channel != curchannel)
    	{
        tstbit[0] = 0;
        lseek(midxinfil, (long) d, SEEK_SET);
        write(midxinfil, tstbit, 1L);
	    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
        continue;
        }

    isaction = 0;
    fixname(msgin.handle, msgin.handle);
	if (!dn && !(forgetstatus[msgin.from] & FGT_FORGOTTEN) &&
		msgin.type != MSG_FORGET && msgin.type != MSG_REMEMBER)
    	{
        top_output(OUT_SCREEN, "\r\n");
    	}
    dn = 0;
    cdc = strtoul(msgin.string, NULL, 10);

	switch(msgin.type)
		{
        case MSG_TEXT:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
            	{
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("MsgPrefix"), msgin.handle,
                           msgin.string);
                mused++;
                }
            proc++;
            break;
        case MSG_ENTRY:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                if (msgin.string[0])
                    {
                    sprintf(outbuf, "^m%s", msgin.string);
                    top_output(OUT_SCREEN, outbuf);
                    }
                else
                    {
                    top_output(OUT_SCREEN, getlang("EMessage"), msgin.handle);
                    }
                mused++;
                }
            proc++;
            fixname(handles[msgin.from].string, msgin.handle);
            activenodes[msgin.from] = 1;
            forgetstatus[msgin.from] = 0;
            break;
        case MSG_EXIT:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                if (msgin.string[0])
                    {
                    sprintf(outbuf, "^m%s", msgin.string);
                    top_output(OUT_SCREEN, outbuf);
                    }
                else
                    {
                    top_output(OUT_SCREEN, getlang("XMessage"), msgin.handle);
                    }
                mused++;
                }
            activenodes[msgin.from] = 0;
            forgetstatus[msgin.from] = 0;
            proc++;
            break;
        case MSG_INEDITOR:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("InProf"), msgin.handle);
                mused++;
                }
            proc++;
            break;
        case MSG_OUTEDITOR:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("OutProf"), msgin.handle);
                mused++;
                }
            proc++;
            break;
        case MSG_WHISPER:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("WhisperPrefix"), msgin.handle,
                           msgin.string);
                mused++;
                }
            proc++;
            break;
        case MSG_GA:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("GAPrefix"), msgin.handle,
                           msgin.string);
                mused++;
                }
            proc++;
            break;
        case MSG_GA2:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("GA2Prefix"), msgin.handle,
                           msgin.string);
                mused++;
                }
            proc++;
            break;
        case MSG_ACTIONSIN:
            isaction = 1;
            allowbits = ALLOW_ME | ALLOW_SEX | ALLOW_SLF;
            proc++;
            break;
        case MSG_ACTIONPLU:
            isaction = 1;
            allowbits = ALLOW_ME | ALLOW_YOU | ALLOW_SEX | ALLOW_POS |
                        ALLOW_SLF;
            proc++;
            break;
        case MSG_TLKTYPSIN:
            isaction = 1;
            allowbits = ALLOW_ME | ALLOW_SEX | ALLOW_SLF;
            proc++;
            break;
        case MSG_TLKTYPPLU:
            isaction = 1;
            allowbits = ALLOW_ME | ALLOW_SEX | ALLOW_SLF;
            proc++;
            break;
        case MSG_ACTPLUSEC:
            isaction = 1;
            allowbits = ALLOW_ME | ALLOW_YOU | ALLOW_SEX | ALLOW_POS |
                        ALLOW_SLF;
            proc++;
            break;
        case MSG_HANDLECHG:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                if (msgin.gender == 0)
                    {
                    strcpy(ttt, getlang("His"));
                    }
                if (msgin.gender == 1)
                    {
                    strcpy(ttt, getlang("Her"));
                    }
                fixname(msgin.string, msgin.string);
                top_output(OUT_SCREEN, getlang("HandleChangeMsg"),
                           handles[msgin.from].string, ttt, msgin.string);
                mused++;
                }
            fixname(handles[msgin.from].string, msgin.string);
            proc++;
            break;
        case MSG_DESCCHG:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                if (msgin.gender == 0)
                    {
                    strcpy(ttt, getlang("His"));
                    }
                if (msgin.gender == 1)
                    {
                    strcpy(ttt, getlang("Her"));
                    }
                mused++;
                top_output(OUT_SCREEN, getlang("DescChangeMsg"), msgin.handle,
                           msgin.string);
                }
            proc++;
            break;
        case MSG_SEXCHG:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("SexChangeMsg"), msgin.handle,
                           msgin.string);
                mused++;
                }
            proc++;
            break;
        case MSG_PERACTCHG:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                if (msgin.gender == 0)
                    {
                    strcpy(ttt, getlang("His"));
                    }
                if (msgin.gender == 1)
                    {
                    strcpy(ttt, getlang("Her"));
                    }
                top_output(OUT_SCREEN, getlang("PersActChangeMsg"), msgin.handle, ttt);
                mused++;
                }
            proc++;
            break;
        case MSG_TOSSOUT:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                top_output(OUT_SCREEN, getlang("TossOut"), msgin.handle);
                mused++;
                }
            activenodes[msgin.from] = 0;
            forgetstatus[msgin.from] = 0;
            proc++;
            break;
        case MSG_FORGET:
            forgetstatus[msgin.from] |= FGT_HASFORGOTME;
            proc++;
            break;
        case MSG_REMEMBER:
            forgetstatus[msgin.from] &= (255 - FGT_HASFORGOTME);
            proc++;
            break;
        // these 3 probably need forget mods later on.
        case MSG_LINKUP:
            delprompt(delname);
            top_output(OUT_SCREEN, getlang("LinkOn"), msgin.handle, msgin.string);
            strcpy(handles[msgin.from].string, msgin.string);
            mused++;
            proc++;
            break;
        case MSG_LINKTEXT:
            delprompt(delname);
            top_output(OUT_SCREEN, getlang("LinkPrefix"), msgin.handle, msgin.string);
            mused++;
            proc++;
            break;
        case MSG_UNLINK:
            delprompt(delname);
            top_output(OUT_SCREEN, getlang("LinkOff"), msgin.handle);
            strcpy(handles[msgin.from].string, msgin.string);
            activenodes[msgin.from] = 0;
            forgetstatus[msgin.from] = 0;
            mused++;
            proc++;
            break;
        case MSG_EXMSGCHG:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
                delprompt(delname);
                if (msgin.gender == 0)
                    {
                    strcpy(ttt, getlang("His"));
                    }
                if (msgin.gender == 1)
                    {
                    strcpy(ttt, getlang("Her"));
                    }
                top_output(OUT_SCREEN, getlang("EXMsgChange"), msgin.handle, ttt);
                mused++;
                }
            proc++;
            break;
        case MSG_TOSSED:
            delprompt(delname);
            top_output(OUT_SCREEN, getlang("HasTossed"), msgin.handle);
            if (msgin.string[0])
            	{
                top_output(OUT_SCREEN, getlang("TossComment"), msgin.string);
                }
            top_output(OUT_SCREEN, "\r\n\r\n");
            tstbit[0] = 0;
		    lseek(midxinfil, (long) d, SEEK_SET);
		    write(midxinfil, tstbit, 1L);
		    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
            od_exit(6, FALSE);
            proc++;
            mused++;
            break;
        case MSG_ZAPPED:
            delprompt(delname);
            top_output(OUT_SCREEN, getlang("HasZapped"), msgin.handle);
            if (msgin.string[0])
            	{
                top_output(OUT_SCREEN, getlang("TossComment"), msgin.string);
                }
            top_output(OUT_SCREEN, "\r\n\r\n");
            tstbit[0] = 0;
		    lseek(midxinfil, (long) d, SEEK_SET);
		    write(midxinfil, tstbit, 1L);
		    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
            od_exit(7, TRUE);
            proc++;
            mused++;
            break;
        case MSG_CLEARNODE:
            delprompt(delname);
            itoa(cdc, outnum[0], 10);
            top_output(OUT_SCREEN, getlang("NodeCleared"), outnum[0],
                       handles[(XINT) cdc].string, msgin.handle);
        	check_nodes_used(0);
            mused++;
            proc++;
            break;
        case MSG_SYSGIVECD:
        	delprompt(delname);
            ultoa(cdc, outnum[0], 10);
            top_output(OUT_SCREEN, getlang("CDGive"), msgin.handle, outnum[0],
                       cdc == 1 ? getlang("CDSingular") :
                                  getlang("CDPlural"));
            user.cybercash += cdc;
            save_user_data(user_rec_num, &user);
            mused++;
            proc++;
            break;
        case MSG_SYSTAKECD:
        	delprompt(delname);
            ultoa(cdc, outnum[0], 10);
            top_output(OUT_SCREEN, getlang("CDTake"), msgin.handle, outnum[0],
                       cdc == 1 ? getlang("CDSingular") :
                                  getlang("CDPlural"));
            user.cybercash -= cdc;
            save_user_data(user_rec_num, &user);
            mused++;
            proc++;
            break;
        case MSG_SYSSETCD:
        	delprompt(delname);
            ultoa(cdc, outnum[0], 10);
            top_output(OUT_SCREEN, getlang("CDSet"), msgin.handle, outnum[0]);
            user.cybercash = cdc;
            save_user_data(user_rec_num, &user);
            mused++;
            proc++;
            break;
        case MSG_POKER:
            if (!stricmp(msgin.string, "WantIn"))
            	{
                pokstacknode[pokcount] = msgin.from;
                pokerstack[pokcount++] = POKER_WANTIN;
                }
            if (!stricmp(msgin.string, "WantOut"))
            	{
                pokstacknode[pokcount] = msgin.from;
                pokerstack[pokcount++] = POKER_WANTOUT;
                }
            if (!stricmp(msgin.string, "Bet"))
            	{
                pokstacknode[pokcount] = msgin.from;
                pokerstack[pokcount++] = POKER_BETIN;
                }
            if (!stricmp(msgin.string, "Discard"))
            	{
                pokstacknode[pokcount] = msgin.from;
                pokerstack[pokcount++] = POKER_DISCIN;
                }
            if (!stricmp(msgin.string, "Fold"))
            	{
                pokstacknode[pokcount] = msgin.from;
                pokerstack[pokcount++] = POKER_FOLDIN;
                }
            if (!stricmp(msgin.string, "Start"))
            	{
                pokstacknode[pokcount] = msgin.from;
                pokerstack[pokcount++] = POKER_START;
                }
            if (!stricmp(msgin.string, "YourBet"))
                {
	        	delprompt(delname);
                poker_loadgamedata(&mgame);
                poker_loadplyrdata(od_control.od_node, &mplyr);
                top_output(OUT_SCREEN, "\a^pIt is your turn to ^kbet^p "
                           "in Poker!\r\n");
                sprintf(outbuf, "^nYou must bet at least ^l%lu^n "
                        "CyberDollar%s to stay in.",
                        mgame.highbet - mplyr.totalbet,
                        (mgame.highbet - mplyr.totalbet) == 1 ?
                        getlang("CDSingular") : getlang("CDPlural"));
                top_output(OUT_SCREEN, outbuf);
                mused++;
                }
            if (!stricmp(msgin.string, "YourDiscard"))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, "\a^pIt is your turn to ^kdiscard^p "
                           "in Poker!");
                mused++;
                }
            if (!stricmp(msgin.string, "HurryBet"))
                {
	        	delprompt(delname);
                poker_loadgamedata(&mgame);
                poker_loadplyrdata(od_control.od_node, &mplyr);

                top_output(OUT_SCREEN, "\a^I^pIt is ^mStill^p\a your turn to "
                           "^kbet^p\a in Poker!  \a^lHurry "
                           "Up!!!^A^o\a\r\n");
                sprintf(outbuf, "^nYou must bet at least ^l%lu^n "
                        "CyberDollar%s to stay in.",
                        mgame.highbet - mplyr.totalbet,
                        (mgame.highbet - mplyr.totalbet) == 1 ?
                        getlang("CDSingular") : getlang("CDPlural"));
                top_output(OUT_SCREEN, outbuf);
                mused++;
                }
            if (!stricmp(msgin.string, "HurryDiscard"))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, "\a^I^pIt is ^mStill^p \ayour turn to "
                           "^kdiscard^p\a in Poker!  \a^lHurry Up!!!^A^o\a");
                mused++;
                }
            if (!stricmp(msgin.string, "ForcedOut"))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, "\a\a\a\a\a^I^mYou have been ^pFORCED^m out "
                           "of Poker for taking too long!^A^m\a\a\a\a\a\r\n");
                top_output(OUT_SCREEN, "When you get back to this universe feel "
                           "free to join in again.");
                pokstacknode[pokcount] = od_control.od_node;
                pokerstack[pokcount++] = POKER_WANTOUT;
                mused++;
                }
            if (!stricmp(msgin.string, "GameOn"))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, "\a^I^pThe ^kPoker^p game has just "
                           "started!^A^n\r\n");
                ultoa(cfg.pokerante, outnum[0], 10);
                top_output(OUT_SCREEN, "The ante of ^l@1^n CyberDollar@2 "
                        "has been automatically deducted from your "
                        "total.", outnum[0], "s");
                user.cybercash -= cfg.pokerante;
                save_user_data(user_rec_num, &user);
                mused++;
                }
            if (!stricmp(msgin.string, "You'reIn"))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, "^pYou will now be playing in the next "
                           "^kPoker^p game!");
                mused++;
                }
            if (!stricmp(msgin.string, "TooManyPeople"))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, "^pThere are too many people playing "
                           "^kPoker^p right now, so you cannot "
                           "join.");
                mused++;
                }
            if (!stricmp(msgin.string, "NotEnoughPeople"))
            	{
                delprompt(delname);
                top_output(OUT_SCREEN, "^mThere are not enough people playing "
                		   "^kPoker^m for a game to start yet.\r\n");
                top_output(OUT_SCREEN, "Why not invite someone to play?");
                mused++;
                }
            if (!stricmp(msgin.string, "GameOver"))
                {
                XINT hsd, maxnamlen;
    		    poker_player_typ hdplyr;
                char winin[256]; // Dynam with MAXNODES!

	        	delprompt(delname);
                poker_loadgamedata(&mgame);
                top_output(OUT_SCREEN, "\r\n^pThe ^kPoker^p game has "
                           "ended!\r\n\r\n");

			    // Need to enhance to show big fancy cards, etc.
                poker_loadintable(0, 0, winin);
	    		for (hsd = 0, maxnamlen = 0; hsd < MAXNODES; hsd++)
                	{
                    if (winin[hsd] > 1)
                    	{
                        if (strlen(handles[hsd].string) > maxnamlen)
                        	{
                            maxnamlen = strlen(handles[hsd].string);
                            }
                        }
                    }
                top_output(OUT_SCREEN, "^nHands:\r\n");
	    		for (hsd = 0; hsd < MAXNODES; hsd++)
		    		{
                    XINT hse;

                    if (winin[hsd] > 1)
                    	{
                        XINT xxq;

                        char btmp[256]; // Dynam with MAXSTRLEN!

                        poker_loadplyrdata(hsd, &hdplyr);

                        sprintf(outbuf, "^l%*s  ", maxnamlen,
                        		handles[hsd].string);
                        top_output(OUT_SCREEN, outbuf);
                        for (hse = 0; hse < 5; hse++) // 5 = maxcards
                        	{
                            // Line below needs mods to display low ascii
							// suit if ibmchars on
                            sprintf(outbuf, "^H^%c%c%c^A ",
									(hdplyr.cards[hse] % 4) > 1 ? 'm' : 'a',
				   		    		card_symbols[hdplyr.cards[hse] % 13],
									card_suits[hdplyr.cards[hse] % 4]);
                            top_output(OUT_SCREEN, outbuf);
                            }
                        top_output(OUT_SCREEN, " ");
                        xxq = wherex();
                        top_output(OUT_SCREEN, poker_getshortname(&hdplyr));
                        od_repeat(' ', 20 - (wherex() - xxq));
                        if (winin[hsd] == 3)
                        	{
                            top_output(OUT_SCREEN, "  ^I^k<-- Winner!^A^h");
                            }
                        top_output(OUT_SCREEN, "\r\n");
                        }
    			    }

                sprintf(outbuf, "\r\n^oThe pot was ^l%lu^o "
                        "CyberDollar%s.\r\n", mgame.pot,
                        mgame.pot == 1 ?
                        getlang("CDSingular") : getlang("CDPlural"));
                top_output(OUT_SCREEN, outbuf);
                if (winin[od_control.od_node] == 3)
                    {
                    unsigned long winamount;

                    assert(mgame.numwinners != 0);
                    winamount = mgame.pot / mgame.numwinners;
                    sprintf(outbuf, "^I^kYou won ^o%lu^k "
                            "CyberDollar%s!!!^A^o", winamount,
                            winamount == 1L ?
                            getlang("CDSingular") : getlang("CDPlural"));
                    top_output(OUT_SCREEN, outbuf);
                    user.cybercash += winamount;
                    save_user_data(user_rec_num, &user);
                    }
                else
                    {
                    top_output(OUT_SCREEN, "^mSorry, you didn't win!  Better luck "
                               "next time!");
                    }
                top_output(OUT_SCREEN, "\r\n");
                mused++;
                }
            proc++;
            break;
        case MSG_GENERIC:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
	            delprompt(delname);
                top_output(OUT_SCREEN, msgin.string);
        	    mused++;
                }
            proc++;
            break;
        case MSG_INCHANNEL:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, getlang("ChannelIn"),
                           msgin.handle);
        	    mused++;
                }
            proc++;
            break;
        case MSG_OUTCHANNEL:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, getlang("ChannelOut"),
                           msgin.handle);
    	        mused++;
                }
            proc++;
            break;
        case MSG_KILLCRASH:
            res = atoi(msgin.string);
            if (!(forgetstatus[res] & FGT_FORGOTTEN))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, getlang("CrashToss"), handles[res].string);
                }
            activenodes[res] = 0;
            forgetstatus[res] = 0;
            mused++;
            proc++;
            break;
        case MSG_DIRECTED:
            if (!(forgetstatus[msgin.from] & FGT_FORGOTTEN))
                {
	        	delprompt(delname);
                top_output(OUT_SCREEN, getlang("DirectedPrefix"),
                		   handles[msgin.from].string,
                		   msgin.doneto == od_control.od_node ?
						   getlang("You") : handles[msgin.doneto].string,
						   msgin.string);
                mused++;
                }
            proc++;
            break;
        case MSG_SYSUSEREDITED:
            delprompt(delname);
            top_output(OUT_SCREEN, getlang("SysopUserEdited"),
            		   msgin.string);
            load_user_data(user_rec_num, &user);
            mused++;
            proc++;
            break;
        }
    if (isaction && !(forgetstatus[msgin.from] & FGT_FORGOTTEN))
        {
        char tmp[356]; // Dynam with MAXSTRLEN!
        XINT c, nxt = 0, proctokon = 1;

        delprompt(delname);
        mused++;
        strset(tmp, '\0');
        for (c = 0; c < strlen(msgin.string); c++)
            {
            if (c == msgin.talktypetextstart)
            	{
                proctokon = 0;
                }
            if (nxt)
                {
                nxt = 2;
                if (toupper(msgin.string[c]) == 'M' &&
                    (allowbits & ALLOW_ME))
                    {
                    strcat(tmp, "^l");
                    strcat(tmp, msgin.handle);
                    strcat(tmp, "^o");
                    }
                if (toupper(msgin.string[c]) == 'Y' &&
                    (allowbits & ALLOW_YOU))
                    {
                    strcat(tmp, "^l");
                    if (msgin.doneto == od_control.od_node)
                        {
                        strcat(tmp, getlang("You"));
                        }
                    if (msgin.doneto == -2)
                        {
                        strcat(tmp, "everyone"); ///!
                        }
                    if ((msgin.doneto >= 0) &&
                        (msgin.doneto != od_control.od_node))
                        {
                        strcat(tmp, handles[msgin.doneto].string);
                        }
                    strcat(tmp, "^o");
                    }
                if (toupper(msgin.string[c]) == 'H' &&
                    (allowbits & ALLOW_SEX))
                    {
                    strcat(tmp, "^p");
                    if (msgin.gender == 0)
                        {
                        strcat(tmp, getlang("His"));
                        }
                    if (msgin.gender == 1)
                        {
                        strcat(tmp, getlang("Her"));
                        }
                    strcat(tmp, "^o");
                    }
                if (toupper(msgin.string[c]) == 'F' &&
                    (allowbits & ALLOW_SLF))
                    {
                    strcat(tmp, "^p");
                    if (msgin.gender == 0)
                        {
                        strcat(tmp, getlang("Himself"));
                        }
                    if (msgin.gender == 1)
                        {
                        strcat(tmp, getlang("Herself"));
                        }
                    strcat(tmp, "^o");
                    }
                if (toupper(msgin.string[c]) == 'S' &&
                    (allowbits & ALLOW_POS))
                    {
                    if (msgin.doneto == od_control.od_node)
                        {
                        strcat(tmp, "^l");
                        strcat(tmp, "r");
                        strcat(tmp, "^o");
                        }
                    else
                        {
                        strcat(tmp, "'s");
                        }
                    }
                }
            if (nxt == 0)
                {
                if (msgin.string[c] == '%' && proctokon)
                    {
                    nxt = 1;
                    }
                else
                    {
                    strncat(tmp, &msgin.string[c], 1);
                    }
                }
            if (nxt == 2)
                {
                nxt = 0;
                }
            }
        top_output(OUT_SCREEN, tmp);
        if (msgin.type == MSG_ACTPLUSEC)
            {
            top_output(OUT_SCREEN, getlang("Secretly"));
            }
        }
    tstbit[0] = 0;
    lseek(midxinfil, (long) d, SEEK_SET);
    write(midxinfil, tstbit, 1L);
    rec_locking(REC_UNLOCK, midxinfil, d, 1L);
    }

for (res = 0; res < pokcount; res++)
	{
    poker_core(pokerstack[res], pokstacknode[res]);
    }

if (delname && mused > 0)
	{
    od_printf("\r\n");
    }

return mused;
}

void delprompt(char dname)
{
XINT dd;

if (dname)
    {
    for (dd = 0; dd < strlen(user.handle) + 2; dd++)
        {
        top_output(OUT_SCREEN, "\b \b");
        }
    }

}
