#include "top.h"

#define TOP_VERSION "2.00.5115"

extern unsigned _stklen = 8192L;

TOP_config_typ cfg;
XINT user_rec_num = -1;
user_data_typ user;
/* stringarray3 XFAR *words = NULL; */
char XFAR *word_str = NULL;
XINT XFAR *word_pos = NULL;
XINT XFAR *word_len = NULL;
stringarray1 XFAR *verbs = NULL;
unsigned char XFAR *actiontypes = NULL;
stringarray2 XFAR *handles = NULL;
unsigned char XFAR *activenodes = NULL;
XINT numactions = 0;
clock_t lastpoll = 0;
unsigned char XFAR *outbuf =NULL;
char isregistered;
RKVALID registeredtop = RK_UNREGISTERED;
unsigned char XFAR *registeredto = NULL;
unsigned char XFAR *regname = NULL;
unsigned char XFAR *regsystem = NULL;
char node_added = 0;
unsigned char XFAR *forgetstatus = NULL;
XINT lastforgetter = -1;
char localmode = 0, lanmode = 0;
struct ffblk actfileinfo;
char XFAR *busynodes = NULL;
struct ffblk ipcfildat;
XINT cfgfil, userfil, nidxfil, nidx2fil, msginfil, msgoutfil, useronfil,
    ipcinfil, ipcoutfil, /*actionfil,*/ rapagefil, midxinfil, midxoutfil,
	chgfil, slotsfil, pokdatafil;
FILE *actionfil = NULL;
struct ffblk midxfileinfo;
unsigned long slotsbet = 0;
XINT lowestnode = 0;
//unsigned char *langtext;
//unsigned long *langstart;
lang_text_typ XFAR **langptrs;
long numlang;
XINT usedcmdlen;
XINT nodecfgfil;
long curchannel;
unsigned char *wordret;
node_idx_typ *node;
unsigned char *outputstr;
XINT matchfil;
TOP_nodecfg_typ *nodecfg;
char outproclang;
char outproccol;
char outprocact;
unsigned XINT outdefattrib;
unsigned char *lastcmd;
channel_data_typ *chan;

unsigned char ver[16] = TOP_VERSION;

// unsigned char XFAR *argptrs[9];
unsigned char outnum[9][12];

char (XFAR *bbs_call_loaduseron)(XINT nodenum, bbsnodedata_typ *userdata) = NULL;
char (XFAR *bbs_call_saveuseron)(XINT nodenum, bbsnodedata_typ *userdata) = NULL;
XINT (XFAR *bbs_call_processmsgs)(void) = NULL;
char (XFAR *bbs_call_page)(XINT nodenum, unsigned char *pagebuf) = NULL;
void (XFAR *bbs_call_setexistbits)(bbsnodedata_typ *userdata) = NULL;
void (XFAR *bbs_call_login)(void) = NULL;
void (XFAR *bbs_call_logout)(void) = NULL;
XINT (XFAR *bbs_call_openfiles)(void) = NULL;
XINT (XFAR *bbs_call_updateopenfiles)(void) = NULL;

unsigned char *bbsnames[BBSTYPES] =
	{
    "Unknown",
    "RemoteAccess 2.0x",
    "Maximus 2.0x",
    "EzyCom 1.20",
    "SuperBBS 1.1x",
    "Concord 0.01"
    };

unsigned char *nodetypes[3] =
	{
    "Remote",
    "Local",
    "Network"
    };

unsigned char poker_nagtimes[6] = { 60, 80, 100, 110, 115, 120 };

unsigned char XFAR *ra_statustypes[8] = ///!!! Starting here...move to dynam
	{
    "Browsing",
    "File Xfer",
    "Messages",
    "In A Door",
    "SysOp Chat",
    "Questions",
    "Conference",
    "New User"
    };

unsigned char XFAR *sbbs_statustypes[11] =
	{
    "Browsing",
    "D'nloading",
    "Uploading",
    "Read Msgs.",
    "Write Msg.",
    "Sysop Chat",
    "In A Door",
    "New User",
    "QWK Mail",
    "File List",
    "Node Chat"
    };

unsigned char XFAR *card_names[14] =
    {
    "Ace",
    "Deuce",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
    "Ten",
    "Jack",
    "Queen",
    "King",
    "Ace"
    };
unsigned char XFAR *card_suitnames[4] =
    {
    "Spade",
    "Club",
    "Heart",
    "Diamond"
    };
unsigned char XFAR card_symbols[14] = "A23456789TJQKA";
unsigned char XFAR card_suits[8] = "SCHDschd"; //\x6\x5\x3\x4";
