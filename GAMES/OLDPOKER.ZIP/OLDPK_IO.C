#include "top.h"

void poker_loadplyrdata(XINT nodenum, poker_player_typ *loaddata)
{

lseek(pokdatafil, (long) (nodenum + 1L) * (long) sizeof(poker_player_typ),
	  SEEK_SET);
rec_locking(REC_LOCK, pokdatafil,
			(long) (nodenum + 1L) * (long) sizeof(poker_player_typ),
			sizeof(poker_player_typ));
read(pokdatafil, loaddata, sizeof(poker_player_typ));
rec_locking(REC_UNLOCK, pokdatafil,
	        (long) (nodenum + 1L) * (long) sizeof(poker_player_typ),
			sizeof(poker_player_typ));

return;
}

void poker_saveplyrdata(XINT nodenum, poker_player_typ *savedata)
{

lseek(pokdatafil, (long) (nodenum + 1L) * (long) sizeof(poker_player_typ),
	  SEEK_SET);
rec_locking(REC_LOCK, pokdatafil,
			(long) (nodenum + 1L) * (long) sizeof(poker_player_typ),
			sizeof(poker_player_typ));
write(pokdatafil, savedata, sizeof(poker_player_typ));
rec_locking(REC_UNLOCK, pokdatafil,
	        (long) (nodenum + 1L) * (long) sizeof(poker_player_typ),
			sizeof(poker_player_typ));

return;
}

void poker_loadgamedata(poker_game_typ *loaddata)
{

lseek(pokdatafil, 0L, SEEK_SET);
rec_locking(REC_LOCK, pokdatafil, 0L, sizeof(poker_game_typ));
read(pokdatafil, loaddata, sizeof(poker_game_typ));
rec_locking(REC_UNLOCK, pokdatafil, 0L, sizeof(poker_game_typ));

return;
}

void poker_savegamedata(poker_game_typ *savedata)
{

lseek(pokdatafil, 0L, SEEK_SET);
rec_locking(REC_LOCK, pokdatafil, 0L, sizeof(poker_game_typ));
write(pokdatafil, savedata, sizeof(poker_game_typ));
rec_locking(REC_UNLOCK, pokdatafil, 0L, sizeof(poker_game_typ));

return;
}

void poker_loadintable(long start, char loadtype, char *dataptr)
{
long ofs, size;

switch(loadtype)
	{
    case 0: ofs = 0L; size = MAXNODES; break;       /* Entire "want in" */
    case 1: ofs = 0L; size = 1L; break;             /* One "want in" */
    case 2: ofs = MAXNODES; size = MAXNODES; break; /* Entire "is in" */
    case 3: ofs = MAXNODES; size = 1L; break;       /* One "is in" */
    }
start += ((long) MAXNODES + 1L) * (long) sizeof(poker_game_typ);

lseek(pokdatafil, start + ofs, SEEK_SET);
rec_locking(REC_LOCK, pokdatafil, start + ofs, size);
read(pokdatafil, dataptr, size);
rec_locking(REC_UNLOCK, pokdatafil, start + ofs, size);

return;
}

void poker_saveintable(long start, char savetype, char *dataptr)
{
long ofs, size;

switch(savetype)
	{
    case 0: ofs = 0L; size = MAXNODES; break;       /* Entire "want in" */
    case 1: ofs = 0L; size = 1L; break;             /* One "want in" */
    case 2: ofs = MAXNODES; size = MAXNODES; break; /* Entire "is in" */
    case 3: ofs = MAXNODES; size = 1L; break;       /* One "is in" */
    }
start += ((long) MAXNODES + 1L) * (long) sizeof(poker_game_typ);

lseek(pokdatafil, start + ofs, SEEK_SET);
rec_locking(REC_LOCK, pokdatafil, start + ofs, size);
write(pokdatafil, dataptr, size);
rec_locking(REC_UNLOCK, pokdatafil, start + ofs, size);

return;
}
