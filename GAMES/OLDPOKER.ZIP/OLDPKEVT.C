#include "top.h"

void poker_event(void)
{
char *whos_in;
poker_game_typ tgame;
poker_player_typ tplyr;

check_nodes_used(1);
if (lowestnode != od_control.od_node)
	{
    return;
    }

whos_in = farmalloc(MAXNODES);
if (!whos_in)
    {
    dispatch_message(MSG_GENERIC, "^I^mNot enough memory to play Poker!^A^p",
                     od_control.od_node, 0, 0);
    return;
    }

poker_loadgamedata(&tgame);
if (!tgame.gameon)
    {
    if (difftime(time(NULL), tgame.eventstarttime) >= 15) // 60!
		{
        poker_loadintable(0, 0, whos_in);
    	if (poker_count(whos_in) > 1)
        	{
			dispatch_message(MSG_POKER, "Start", lowestnode,
						     1, 0);
            tgame.gameprogress = 0;
            }
        else
        	{
            XINT nnd;

            for (nnd = 0; nnd < MAXNODES; nnd++)
            	{
                if (whos_in[nnd])
                	{
                    dispatch_message(MSG_POKER, "NotEnoughPeople", nnd,
									 1, 0);
                    }
                }
            }
	    time(&tgame.eventstarttime);
	    poker_savegamedata(&tgame);
        }
	}
if (tgame.gameon)
	{
    poker_loadplyrdata(tgame.currentturn, &tplyr);
    if (difftime(time(NULL), tgame.eventstarttime) >=
		poker_nagtimes[tplyr.numnags])
    	{
        if (tplyr.numnags < 5)
        	{
		    if (tgame.gameprogress == 50)
    			{
        		dispatch_message(MSG_POKER, "HurryDiscard",
								 tgame.currentturn, 1, 0);
		        }
    		else
    			{
	        	dispatch_message(MSG_POKER, "HurryBet", tgame.currentturn,
								 1, 0);
	    	    }
	        tplyr.numnags++;
	        poker_saveplyrdata(tgame.currentturn, &tplyr);
            }
        else
        	{
		    dispatch_message(MSG_POKER, "ForcedOut", tgame.currentturn,
							 1, 0);
		    time(&tgame.eventstarttime);
		    poker_savegamedata(&tgame);
            }
        }
    }

dofree(whos_in);

return;
}
