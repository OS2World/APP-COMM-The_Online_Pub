#include "top.h"

void poker_core(XINT task, XINT fromnode)
{
XINT pd, pcc;
char tcards[10], tmpbit, *whos_in;
poker_game_typ tgame;
poker_player_typ tplyr;

whos_in = farmalloc(MAXNODES);
if (!whos_in)
    {
    dispatch_message(MSG_GENERIC, "^I^mNot enough memory to play Poker!^A^p",
                     od_control.od_node, 0, 0);
    return;
    }

poker_loadgamedata(&tgame);
switch(task)
	{
	case POKER_START:
        poker_loadintable(0, 0, whos_in);
        poker_saveintable(0, 2, whos_in);

		memset(&tgame, 0, sizeof(poker_game_typ));
//        tgame.gametype = POKGAME_5DRAW;

		for (pd = 0; pd < MAXNODES; pd++)
			{
			if (!whos_in[pd])
				{
				continue;
				}

			for (pcc = 0; pcc < 5; pcc++)
				{
				do
					{
					tcards[pcc] = random(52);
					}
				while(tgame.cardsused[tcards[pcc]]);
                tgame.cardsused[tcards[pcc]] = 1;
				}

            memset(&tplyr, 0, sizeof(poker_player_typ));
            memcpy(tplyr.cards, tcards, 10L);
            poker_sorthand(&tplyr);
            poker_saveplyrdata(pd, &tplyr);
			}

        for (pd = 0; pd < MAXNODES; pd++)
        	{
			if (whos_in[pd])
            	{
                dispatch_message(MSG_POKER, "GameOn", pd, 1, 0);
                }
            }
        tgame.roundprogress = 0;
        poker_advanceturn(-1, whos_in, &tgame);
        tgame.acehigh = 1;
        tgame.pot += ((long) poker_count(whos_in) * cfg.pokerante);
        tgame.gameon = 1;
		break;
	case POKER_BETIN:
        poker_loadplyrdata(fromnode, &tplyr);
        if (tplyr.totalbet + tplyr.thisbet == tgame.highbet)
        	{
	        tgame.roundprogress++;
            sprintf(outbuf, "^l%s^n calls the ^kPoker^n bet.  "
            		"(^l%lu^n CyberDollar%s)", handles[fromnode].string,
                    tplyr.thisbet, tplyr.thisbet == 1 ? "" : "s");
            }
		else
        	{
            tgame.roundprogress = 1;
            sprintf(outbuf, "^l%s^n calls the ^kPoker^n bet "
            		"(^l%lu^n CyberDollar%s), and raises by ^l%lu^n "
                    "CyberDollar%s!", handles[fromnode].string,
                    tgame.highbet - tplyr.totalbet,
                    (tgame.highbet - tplyr.totalbet) == 1 ? "" : "s",
                    tplyr.thisbet - (tgame.highbet - tplyr.totalbet),
					(tplyr.thisbet - (tgame.highbet - tplyr.totalbet)) == 1 ?
						"" : "s");
            }

        poker_loadintable(0, 0, whos_in);
        for (pcc = 0; pcc < MAXNODES; pcc++)
        	{
            if (whos_in[pcc] && pcc != fromnode)
            	{
                dispatch_message(MSG_GENERIC, outbuf, pcc, 1, 0);
                }
            }

        tplyr.totalbet += tplyr.thisbet;
        tgame.highbet = tplyr.totalbet;
        tgame.pot += tplyr.thisbet;
        tplyr.numnags = 0;
        poker_saveplyrdata(fromnode, &tplyr);
        poker_loadintable(0, 2, whos_in);
        pcc = poker_lownode(fromnode, whos_in);
        poker_advanceturn(pcc, whos_in, &tgame);
		break;
	case POKER_DISCIN:
        poker_loadplyrdata(fromnode, &tplyr);
        memcpy(&tcards[0], &tplyr.cards[0], 10L);

        poker_shuffle(tcards);

        for (pd = 0; pd < 5; pd++) // 5---> numcards
        	{
            if (tplyr.discards[pd])
            	{
                tgame.cardsused[tcards[pd]] = 2;
				do
					{
                	tcards[pd] = random(52);
                    }
				while(tgame.cardsused[tcards[pd]]);
                tgame.cardsused[tcards[pd]] = 1;
                sprintf(outbuf, "^pYou draw a%s ^k%s^p of "
						"^k%ss^p!", (tcards[pd] % 13 == 0) ||
						(tcards[pd] % 13 == 7) ? "n" : "",
						card_names[tcards[pd] % 13],
						card_suitnames[tcards[pd] % 4]);
                dispatch_message(MSG_GENERIC, outbuf, fromnode, 1, 0);
                }
            }

        	{
            XINT ddis;

            for (pcc = 0, ddis = 0; pcc < 5; pcc++)
            	{
                if (tplyr.discards[pcc])
                	{
                    ddis++;
                    }
                }

            sprintf(outbuf, "^l%s^n discards ^l%i^n card%s.",
					handles[fromnode].string, ddis, ddis == 1 ? "" : "s");
            }
        poker_loadintable(0, 0, whos_in);
        for (pcc = 0; pcc < MAXNODES; pcc++)
        	{
            if (whos_in[pcc] && pcc != fromnode)
            	{
                dispatch_message(MSG_GENERIC, outbuf, pcc, 1, 0);
                }
            }

        memcpy(tplyr.cards, tcards, 10L);
        poker_sorthand(&tplyr);
        tplyr.numnags = 0;
		poker_saveplyrdata(fromnode, &tplyr);
        poker_loadintable(0, 2, whos_in);
        tgame.roundprogress++;
        pcc = poker_lownode(fromnode, whos_in);
        poker_advanceturn(pcc, whos_in, &tgame);
		break;
	case POKER_FOLDIN:
        poker_loadplyrdata(fromnode, &tplyr);
        tmpbit = 0;
        poker_saveintable(fromnode, 3, &tmpbit);
        for (pd = 0; pd < 5; pd++)
        	{
            tgame.cardsused[tplyr.cards[pd]] = 2;
            }

        	{
            node_idx_typ tnidx;

            get_node_data(fromnode, &tnidx);
            sprintf(outbuf, "^l%s^n folds %s ^kPoker^n hand.",
            		handles[fromnode].string,
					tnidx.gender == 0 ? "his" : "her");
            }
        poker_loadintable(0, 0, whos_in);
        for (pcc = 0; pcc < MAXNODES; pcc++)
        	{
            if (whos_in[pcc] && pcc != fromnode)
            	{
                dispatch_message(MSG_GENERIC, outbuf, pcc, 1, 0);
                }
            }

        poker_loadintable(0, 2, whos_in);
        if (fromnode == tgame.currentturn)
        	{
            pcc = poker_lownode(fromnode, whos_in);
            poker_advanceturn(pcc, whos_in, &tgame);
            }
        if (poker_count(whos_in) <= 1 && tgame.gameon)
        	{
            poker_advanceturn(-1, whos_in, &tgame);
            }
		break;
    case POKER_WANTIN:
        poker_loadintable(0, 0, whos_in);
        if (poker_count(whos_in) < 9)
        	{
            tmpbit = 1;
            poker_saveintable(fromnode, 1, &tmpbit);
            dispatch_message(MSG_POKER, "You'reIn", fromnode, 1, 0);

            sprintf(outbuf, "^l%s^n asks to be dealt into the next "
            		"^kPoker^n game!", handles[fromnode].string);
            poker_loadintable(0, 0, whos_in);
    	    for (pcc = 0; pcc < MAXNODES; pcc++)
        		{
            	if (whos_in[pcc] && pcc != fromnode)
	            	{
    	            dispatch_message(MSG_GENERIC, outbuf, pcc, 1, 0);
        	        }
            	}
            }
        else
        	{
            dispatch_message(MSG_POKER, "TooManyPeople", fromnode, 1, 0);
            }
    	break;
    case POKER_WANTOUT:
        sprintf(outbuf, "^l%s^n asks to be dealt out of the next "
        		"^kPoker^n game.", handles[fromnode].string);
        poker_loadintable(0, 0, whos_in);
	    for (pcc = 0; pcc < MAXNODES; pcc++)
    		{
        	if (whos_in[pcc] && pcc != fromnode)
	         	{
	            dispatch_message(MSG_GENERIC, outbuf, pcc, 1, 0);
    	        }
        	}
        poker_loadintable(fromnode, 3, &tmpbit);
        if (tmpbit)
        	{
            for (pd = 0; pd < 5; pd++)
	        	{
    	        tgame.cardsused[tplyr.cards[pd]] = 2;
        	    }

	        	{
    	        node_idx_typ tnidx;

	            get_node_data(fromnode, &tnidx);
                sprintf(outbuf, "^l%s^n folds %s ^kPoker^n hand.",
            			handles[fromnode].string,
						tnidx.gender == 0 ? "his" : "her");
	            }
            poker_loadintable(0, 0, whos_in);
        	for (pcc = 0; pcc < MAXNODES; pcc++)
        		{
	            if (whos_in[pcc] && pcc != fromnode)
    	        	{
        	        dispatch_message(MSG_GENERIC, outbuf, pcc, 1, 0);
            	    }
	            }
            }
        tmpbit = 0;
        poker_saveintable(fromnode, 1, &tmpbit);
        poker_saveintable(fromnode, 3, &tmpbit);
        poker_loadintable(0, 2, whos_in);
        if (fromnode == tgame.currentturn)
        	{
            pcc = poker_lownode(fromnode, whos_in);
            poker_advanceturn(pcc, whos_in, &tgame);
            }
        if (poker_count(whos_in) <= 1 && tgame.gameon)
        	{
            poker_advanceturn(-1, whos_in, &tgame);
            }
        break;
	}
poker_savegamedata(&tgame);

dofree(whos_in);

return;
}
