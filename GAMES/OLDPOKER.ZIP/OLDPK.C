#include "top.h"

void poker_game(void)//////!!!!!!!!!!!Entire series of modules
{
char wasused = 0;
poker_game_typ tgame;
poker_player_typ tplyr; ////proc
unsigned long tmpbet;

if (!stricmp(get_word(1), "BET") || !stricmp(get_word(1), "RAISE") ||
	!stricmp(get_word(1), "CALL"))
	{
    poker_loadgamedata(&tgame);
    if (tgame.currentturn != od_control.od_node ||
		tgame.gameprogress == 50)
    	{
        top_output(OUT_SCREEN, getlang("PokerNotYourTurn"));
        }
    else
    	{
        poker_loadplyrdata(od_control.od_node, &tplyr);
        if (!get_word_char(2, 0) && stricmp(get_word(1), "CALL"))
            {
            top_output(OUT_SCREEN, getlang("PokerNoBet"),  ///!!! below
                       !stricmp(get_word(1), "RAISE") ? "RAISE" : "BET");
            }
        else
            {
            if (!stricmp(get_word(1), "CALL"))
                {
                tmpbet = tgame.highbet - tplyr.totalbet;
                }
            else
                {
	            tmpbet = 0;
                if (!stricmp(get_word(1), "RAISE"))
                    {
                    tmpbet = tgame.highbet - tplyr.totalbet;
                    }
                tmpbet += strtoul(get_word(2), NULL, 10);
                }

            if (tmpbet > user.cybercash)
                {
                ultoa(tmpbet, outnum[0], 10);
                ultoa(user.cybercash, outnum[1], 10);
                top_output(OUT_SCREEN, getlang("PokerNotEnoughCash"),
                           outnum[0], outnum[1]);
                }
            else
                {
                if (tplyr.totalbet + tmpbet < tgame.highbet)
                    {
                    ultoa(tmpbet, outnum[0], 10);
                    ultoa(tgame.highbet - tplyr.totalbet, outnum[1], 10);
                    top_output(OUT_SCREEN, getlang("PokerBetTooLow",
                               outnum[0], outnum[1]);
                    }
                else
                    {
                    if ((((tplyr.totalbet + tmpbet) - tgame.highbet <
                        cfg.pokerminbet) || ((tplyr.totalbet + tmpbet) -
                        tgame.highbet > cfg.pokermaxbet)) && ((tplyr.totalbet
                        + tmpbet) - tgame.highbet != 0))
                        {
                        ultoa(cfg.pokerminbet, outnum[0], 10);
                        ultoa(cfg.pokermaxbet, outnum[1], 10);
                        top_output(OUT_SCREEN, getlang("PokerInvalidBet"),
                                   outnum[0], outnum[1]);
                        }
                    else
                        {
                        if (tmpbet == tgame.highbet - tplyr.totalbet)
                        	{
                            ultoa(tmpbet, outnum[0], 10);
                            top_output(OUT_SCREEN, getlang("PokerCall"),
                                       outnum[0],
                                       getlang(tmpbet == 1 ? "CDSingular" :
                                               "CDPlural"));
                            }
                        else
                        	{
                            ultoa(tgame.highbet - tplyr.totalbet,
                                  outnum[0], 10);
                            ultoa(tmpbet - (tgame.highbet - tplyr.totalbet),
                                  outnum[1], 10);
                            top_output(OUT_SCREEN, getlang("PokerRaise"),
                                       outnum[0],
                                       getlang((tgame.highbet -
                                                tplyr.totalbet) == 1 ?
                                               "CDSingular" : "CDPlural"),
                                       outnum[1],
                                       getlang((tmpbet - (tgame.highbet -
                                                tplyr.totalbet)) == 1 ?
                                                "CDSingular" : "CDPlural"));
                            }
                        tplyr.thisbet = tmpbet;
                        poker_saveplyrdata(od_control.od_node,
                                           &tplyr);
                        check_nodes_used(1);
                        dispatch_message(MSG_POKER, "Bet", lowestnode,
                                         1, 0);
                        user.cybercash -= tmpbet;
                        save_user_data(user_rec_num, &user);
                        }
                    }
                }
            }
        }
    wasused = 1;
    }
if (!stricmp(get_word(1), "DISCARD") || !stricmp(get_word(1), "STAND"))
	{
    XINT dd, disd;

    poker_loadgamedata(&tgame);
    if (tgame.currentturn != od_control.od_node ||
		tgame.gameprogress != 50)
    	{
        top_output(OUT_SCREEN, "PokerNoDiscardYet");
        }
	else
    	{
        poker_loadplyrdata(od_control.od_node, &tplyr);
    	for (dd = 0, disd = 0; dd < 5; dd++)
    		{
	        tplyr.discards[dd] = 0;
		    if (!stricmp(get_word(1), "DISCARD") &&
				strchr(word_str, dd + '1'))
        		{
            	tplyr.discards[dd] = 1;
	            disd++;
    	        }
        	}
        poker_saveplyrdata(od_control.od_node, &tplyr);
    	check_nodes_used(1);
		dispatch_message(MSG_POKER, "Discard", lowestnode, 1, 0);
        itoa(disd, outnum[0], 10);
        top_output(OUT_SCREEN, getlang("PokerYouDiscard"),
                   outnum[0],
                   getlang(disd == 1 ? "CDSingular" : "CDPlural"));
    	}
    wasused = 1;
    }
if (!stricmp(get_word(1), "FOLD"))
	{
    char tbit;

    poker_loadintable(od_control.od_node, 3, &tbit);
    if (!tbit)
    	{
        top_output(OUT_SCREEN, getlang("PokerNotPlaying"));
        }
    else
    	{
        check_nodes_used(1);
	    dispatch_message(MSG_POKER, "Fold", lowestnode, 1, 0);
        top_output(OUT_SCREEN, getlang("PokerYouFold"));
        }
    wasused = 1;
    }
if (!stricmp(get_word(1), "HAND"))
	{
    XINT hsd;

    char tbit;

    poker_loadintable(od_control.od_node, 3, &tbit);
    if (!tbit)
    	{
        top_output(OUT_SCREEN, getlang("PokerNotPlaying"));
        }
    else
    	{
        poker_loadplyrdata(od_control.od_node, &tplyr);
        poker_sorthand(&tplyr);
        poker_saveplyrdata(od_control.od_node, &tplyr);
	    // Need to enhance to show big fancy cards, etc.
        top_output(OUT_SCREEN, getlang("PokerYourHand")); ///~~
	    for (hsd = 0; hsd < 5; hsd++) // 5 = numcards
    		{
        	// Line below needs mods to display low ascii suit if ibmchars on
            sprintf(outbuf, "^H^%c%c%c%s",
					(tplyr.cards[hsd] % 4) > 1 ? 'm' : 'a',
    	    		card_symbols[tplyr.cards[hsd] % 13],
					card_suits[tplyr.cards[hsd] % 4],
					hsd == 4 ? "^A\r\n" : "^A ");
            top_output(OUT_SCREEN, outbuf);
    	    }
        sprintf(outbuf, "%s^p\r\n", poker_gethandname(&tplyr));
        top_output(OUT_SCREEN, outbuf);
        }
    wasused = 1;
    }
if (!stricmp(get_word(1), "POT"))
	{
    poker_loadgamedata(&tgame);
    sprintf(outbuf, "\r\n^nThe current Poker pot is ^l%lu^n "
			"CyberDollar%s.\r\n", tgame.pot, tgame.pot == 1 ? "" : "s");
    top_output(OUT_SCREEN, outbuf);
    wasused = 1;
    }
if (!stricmp(get_word(1), "TURN"))
	{
    poker_loadgamedata(&tgame);
    if (tgame.gameon)
    	{
        sprintf(outbuf, "\r\n^nIt is currently ^l%s^n's turn to "
				"^k%s^n in Poker.\r\n", handles[tgame.currentturn].string,
        	    tgame.gameprogress == 50 ? "discard" : "bet");
        top_output(OUT_SCREEN, outbuf);
        if (tgame.gameprogress != 50 &&
            tgame.currentturn == od_control.od_node)
            {
            poker_loadplyrdata(od_control.od_node, &tplyr);
            sprintf(outbuf, "^nYou must bet at least ^l%lu^n "
                    "CyberDollar%s to stay in.\r\n",
                    tgame.highbet - tplyr.totalbet,
                    (tgame.highbet - tplyr.totalbet) == 1 ? "" : "s");
            top_output(OUT_SCREEN, outbuf);
            }
        }
    else
    	{
        top_output(OUT_SCREEN, "\r\n^mThere is no ^pPoker^m game currently "
        		   "underway!\r\n");
        }
    wasused = 1;
    }
if (!stricmp(get_word(1), "SCAN") || !stricmp(get_word(1), "WHO"))
	{
    char *tmpin1, *tmpin2;
    XINT whod;

    tmpin1 = farmalloc(MAXNODES);
    if (!tmpin1)
        {
        top_output(OUT_SCREEN, "\r\n^I^mCan't SCAN Poker!^A^p\r\n");
        return;
        }
    tmpin2 = farmalloc(MAXNODES);
    if (!tmpin2)
        {
        top_output(OUT_SCREEN, "\r\n^I^mCan't SCAN Poker!^A^p\r\n");
        dofree(tmpin1);
        return;
        }

    poker_loadintable(0, 0, tmpin1);
    poker_loadintable(0, 2, tmpin2);

    if (poker_count(tmpin1) == 0)
    	{
        top_output(OUT_SCREEN, "\r\n^mNobody is currently playing ^pPoker^m!\r\n");
        }
    else
     	{
        top_output(OUT_SCREEN, "\r\n\r\n             ^pPeople Playing Poker\r\n");
        top_output(OUT_SCREEN, "^c+--------------------------------+----------+\r\n");
        top_output(OUT_SCREEN, "| ^mHandle                         ^c| ^mPlaying? ^c|\r\n");
        top_output(OUT_SCREEN, "+--------------------------------+----------+\r\n");
	    for (whod = 0; whod < MAXNODES; whod++)
    		{
        	if (tmpin1[whod])
        		{
                sprintf(outbuf, "| ^n%-30s ^c|   %s    ^c|\r\n",
    	        		handles[whod].string,
						tmpin2[whod] ? "^kYes" : "^h No");
                top_output(OUT_SCREEN, outbuf);
	            }
    	    }
        top_output(OUT_SCREEN, "+--------------------------------+----------+\r\n\r\n");
    	}
    dofree(tmpin1); dofree(tmpin2);
    wasused = 1;
	}
// View      - Load cards of other player, show upcards (Stud only).
if (!stricmp(get_word(1), "ON"))
	{
    if (user.cybercash < cfg.pokerante)
    	{
        ultoa(cfg.pokerante, outnum[0], 10);
        ultoa(user.cybercash, outnum[1], 10);
        top_output(OUT_SCREEN, "@c^mYou don't have enough CyberCash to play "
        		   "Poker!  (Needed = ^l@1^m, CyberCash = ^l@2^m)@c",
                   outnum[0], outnum[1]);
        return;
        }

    check_nodes_used(1);
    dispatch_message(MSG_POKER, "WantIn", lowestnode, 1, 0);
    top_output(OUT_SCREEN, "\r\n^kProcessing ^pPoker^k request.\r\n");
    wasused = 1;
    }
if (!stricmp(get_word(1), "OFF"))
	{
    check_nodes_used(1);
    dispatch_message(MSG_POKER, "WantOut", lowestnode, 1, 0);
    top_output(OUT_SCREEN, "\r\n^kOkay, you will no longer be playing in any "
			   "^pPoker^k games.\r\n");
    wasused = 1;
    }
if (!stricmp(get_word(1), "CHEAT!"))
    {
    poker_loadgamedata(&tgame);
    if (atoi(get_word(2)) < 0 || atoi(get_word(2)) > 51)
        {
        top_output(OUT_SCREEN, "\r\nBad physical card number (should be 0-51)!\r\n");
        }
    else
        {
        if (atoi(get_word(3)) < 0 || atoi(get_word(3)) > 4)
            {
            top_output(OUT_SCREEN, "\r\n^mBad hand card number (should be 0-4)!\r\n");
            }
        else
            {
            if (tgame.cardsused[atoi(get_word(2))])
                {
                top_output(OUT_SCREEN, "\r\n^mCard is in use!\r\n");
                }
            else
                {
                poker_loadplyrdata(od_control.od_node, &tplyr);
                tgame.cardsused[tplyr.cards[atoi(get_word(3))]] = 0;
                tgame.cardsused[atoi(get_word(2))] = 1;
                tplyr.cards[atoi(get_word(3))] = atoi(get_word(2));
                poker_saveplyrdata(od_control.od_node, &tplyr);
                poker_savegamedata(&tgame);
                top_output(OUT_SCREEN, "\r\n^I^mOooo, sneaky!^A \r\n");
                }
            }
        }
    wasused = 1;
    }

if (!wasused)
	{
    top_output(OUT_SCREEN, "\r\n\r\n^oTOP Poker ^h- ^pCommands\r\n");
    top_output(OUT_SCREEN, "^c--------------------\r\n\r\n");
    top_output(OUT_SCREEN, "^lHELP          ^g- ^mThis help screen.\r\n");
    top_output(OUT_SCREEN, "^lBET xxxxx     ^g- ^mMake a bet of xxxxx CyberDollars.\r\n");
    top_output(OUT_SCREEN, "^lCALL          ^g- ^mCall the current bet.\r\n");
    top_output(OUT_SCREEN, "^lRAISE xxxxx   ^g- ^mRaise the bet by xxxxx CyberDollars.\r\n");
    top_output(OUT_SCREEN, "^lDISCARD 12345 ^g- ^mDiscard card numbers.  Omit a number to keep that card.\r\n");
    top_output(OUT_SCREEN, "^lSTAND         ^g- ^mStand (discard no cards).\r\n");
    top_output(OUT_SCREEN, "^lFOLD          ^g- ^mFold your hand.\r\n");
    top_output(OUT_SCREEN, "^lHAND          ^g- ^mView your hand.\r\n");
    top_output(OUT_SCREEN, "^lPOT           ^g- ^mView the current pot.\r\n");
    top_output(OUT_SCREEN, "^lTURN          ^g- ^mSee who's turn it is.\r\n");
    top_output(OUT_SCREEN, "^lWHO           ^g- ^mSee who is playing.\r\n");
    top_output(OUT_SCREEN, "^lSCAN          ^g- ^mSee who is playing.\r\n");
//    top_output(OUT_SCREEN, "^lVIEW player   ^g- ^mView player's upcards (Stud Poker only).\r\n");
    top_output(OUT_SCREEN, "^lON            ^g- ^mTurn Poker on!\r\n");
    top_output(OUT_SCREEN, "^lOFF           ^g- ^mTurn Poker off.\r\n");
    top_output(OUT_SCREEN, "\r\n");
	}

}
