#include "top.h"

XINT poker_lownode(XINT startnode, char *intable)
{
XINT pld, ret = -1;

for (pld = startnode + 1; pld < MAXNODES; pld++)
	{
    if (intable[pld])
    	{
        ret = pld;
        break;
        }
    }

return ret;
}

XINT poker_count(char *intable)
{
XINT pcd, ret = 0;

for (pcd = 0; pcd < MAXNODES; pcd++)
	{
    if (intable[pcd])
    	{
        ret++;
        }
    }

return ret;
}

void poker_shuffle(char *cardz)
{
XINT psd, psc;

for (psd = 0, psc = 0; psd < 52; psd++)  // 52 = gamecardsused
	{
	if (cardz[psd])
		{
        psc++;
        }
    }
if (psc > 47)
	{
    for (psd = 0; psd < 52; psd++) // 52 = gamecardsused
    	{
        if (cardz[psd] == 2)
        	{
            cardz[psd] = 0;
            }
        }
    }

return;
}

void poker_advanceturn(XINT mini, char *whobuf, poker_game_typ *gamebuf)
{
char *whowant;

whowant = farmalloc(MAXNODES);
if (!whowant)
    {
    dispatch_message(MSG_GENERIC, "^I^mNot enough memory to play Poker!^A^p",
                     od_control.od_node, 0, 0);
    return;
    }

if (poker_count(whobuf) == 1)
	{
    gamebuf->gameprogress = -1;
    }

if (mini == -1)
	{
    mini = poker_lownode(0, whobuf);
    }

if (gamebuf->roundprogress >= poker_count(whobuf))
	{
    if (gamebuf->gameprogress == 100)
    	{
        gamebuf->gameprogress = -1;
        }
    if (gamebuf->gameprogress == 50)
    	{
        gamebuf->gameprogress = 100;
        }
    if (gamebuf->gameprogress == 0)
    	{
        gamebuf->gameprogress = 50;
        }
    mini = poker_lownode(0, whobuf);
    gamebuf->roundprogress = 0;
	}

if (gamebuf->gameprogress == 0 || gamebuf->gameprogress == 100)
	{
    dispatch_message(MSG_POKER, "YourBet", mini, 1, 0);
    }
if (gamebuf->gameprogress == 50)
	{
    dispatch_message(MSG_POKER, "YourDiscard", mini, 1, 0);
    }
if (gamebuf->gameprogress == -1)
	{
    XINT god;
    char *whowas;

    whowas = farmalloc(MAXNODES);
    if (!whowas)
        {
        dispatch_message(MSG_GENERIC, "^I^mNot enough memory to play Poker!^A^p",
                         od_control.od_node, 0, 0);
        dofree(whowant);
        return;
        }

    poker_findwinners(whobuf, gamebuf);
    poker_loadintable(0, 0, whowant);
    poker_loadintable(0, 2, whowas);
    for (god = 0; god < MAXNODES; god++)
    	{
        XINT gdw;

        if (whowant[god])
        	{
            whowant[god] = 1;
	        if (whowas[god])
    	    	{
        	    whowant[god] = 2;
            	}
			for (gdw = 0; gdw < 10; gdw++)
				{
				if (gamebuf->winners[gdw] == god)
            		{
                	whowant[god] = 3;
	                }
    	        }
        	}
        }
    poker_saveintable(0, 0, whowant);
    memset(whowas, 0, MAXNODES);
    poker_saveintable(0, 2, whowas);
    gamebuf->gameprogress = -1;
    gamebuf->gameon = 0;
    mini = -1;
    poker_savegamedata(gamebuf);

    for (god = 0; god < MAXNODES; god++)
    	{
        if (whowant[god])
        	{
		    dispatch_message(MSG_POKER, "GameOver", god, 1, 0);
            }
        }

    dofree(whowant);
    }

gamebuf->currentturn = mini;
time(&gamebuf->eventstarttime);

dofree(whowant);

return;
}

