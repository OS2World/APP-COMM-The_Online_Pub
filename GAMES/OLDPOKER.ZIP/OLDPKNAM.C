#include "top.h"

char XFAR *poker_gethandname(poker_player_typ *handdat)
{
char XFAR *handnam;
unsigned char val[2];
unsigned XINT handval;
unsigned XINT hscore;

handnam = wordret;

hscore = poker_scorehand(handdat);
val[0] = hscore & 0x000F; /* First Hand Value Parameter */
val[1] = (hscore & 0x00F0) >> 4; /* Second Hand Value Parameter */
handval = hscore & 0xF000; /* Hand Type */

if (handval == POKHAND_HIGHCARD)
	{
    sprintf(handnam, "^pHigh Card (^k%s^p).", card_names[val[0]]);
    }
if (handval == POKHAND_ONEPAIR)
	{
    sprintf(handnam, "^pA pair of ^k%s%s^p.", card_names[val[0]],
    		val[0] == 5 ? "es" : "s");
    }
if (handval == POKHAND_TWOPAIR)
	{
    sprintf(handnam, "^pTwo pair, ^k%s%s^p and ^k%s%s^p!",
    		card_names[val[1]], val[1] == 5 ? "es" : "s",
    		card_names[val[0]], val[0] == 5 ? "es" : "s");
    }
if (handval == POKHAND_THREEKIND)
	{
    sprintf(handnam, "^pThree ^k%s%s^p!!",
    		card_names[val[0]], val[0] == 5 ? "es" : "s");
    }
if (handval == POKHAND_STRAIGHT)
	{
    sprintf(handnam, "^I^pA%s ^k%s^p high straight!!!",
    		(val[0] == 0 || val[0] == 7 || val[0] == 13) ? "n" : "",
            card_names[val[0]]);
    }
if (handval == POKHAND_FLUSH)
	{
    sprintf(handnam, "^I^pA flush in ^k%ss^p (^k%s^p high)!!!!",
    		card_suitnames[handdat->cards[4] % 4], card_names[val[0]]);
    }
if (handval == POKHAND_FULLHOUSE)
	{
    sprintf(handnam, "^I^pA full house, ^k%s%s^p over ^k%s%s^p!!!!!",
    		card_names[val[1]], val[1] == 5 ? "es" : "s",
    		card_names[val[0]], val[0] == 5 ? "es" : "s");
    }
if (handval == POKHAND_FOURKIND)
	{
    sprintf(handnam, "^I^pFour ^k%s%s^p!!!!!!",
    		card_names[val[0]], val[0] == 5 ? "es" : "s");
    }
if (handval == POKHAND_STRAIGHTFLUSH)
	{
    if (hscore == POKHAND_ROYALFLUSH)
    	{
        sprintf(handnam, "^I^pA ROYAL FLUSH IN ^k%ss^p!!!!!!!!!!!!!!!",
				card_suitnames[handdat->cards[4] % 4]);
        }
    else
    	{
        sprintf(handnam, "^I^pA straight flush in ^k%ss^p (^k%s^p "
				"high)!!!!!!!!", card_suitnames[handdat->cards[4] % 4],
				card_names[val[0]]);
        }
    }

return handnam;
}

char XFAR *poker_getshortname(poker_player_typ *handdat)
{
char XFAR *handnam;
unsigned char val[2];
unsigned XINT handval;
unsigned XINT hscore;

handnam = wordret;

hscore = poker_scorehand(handdat);
val[0] = hscore & 0x000F; /* First Hand Value Parameter */
val[1] = (hscore & 0x00F0) >> 4; /* Second Hand Value Parameter */
handval = hscore & 0xF000; /* Hand Type */

if (handval == POKHAND_HIGHCARD)
	{
    sprintf(handnam, "^k%c^p High", card_symbols[val[0]]);
    }
if (handval == POKHAND_ONEPAIR)
	{
    sprintf(handnam, "^pPair Of ^k%c^ps", card_symbols[val[0]]);
    }
if (handval == POKHAND_TWOPAIR)
	{
    sprintf(handnam, "^pTwo Pair (^k%c^ps & ^k%c^ps)",
			card_symbols[val[1]], card_symbols[val[0]]);
	}
if (handval == POKHAND_THREEKIND)
	{
    sprintf(handnam, "^pThree ^k%c^ps", card_symbols[val[0]]);
    }
if (handval == POKHAND_STRAIGHT)
	{
    sprintf(handnam, "^k%c^p High Straight", card_symbols[val[0]]);
    }
if (handval == POKHAND_FLUSH)
	{
    sprintf(handnam, "^pFlush (^k%c^p, ^k%c^p High)",
    		card_suits[handdat->cards[4] % 4], card_symbols[val[0]]);
    }
if (handval == POKHAND_FULLHOUSE)
	{
    sprintf(handnam, "^pFull House (^k%c^p/^k%c^p)",
    		card_symbols[val[1]], card_symbols[val[0]]);
    }
if (handval == POKHAND_FOURKIND)
	{
    sprintf(handnam, "^pFour ^k%c^ps", card_symbols[val[0]]);
    }
if (handval == POKHAND_STRAIGHTFLUSH)
	{
    if (hscore == POKHAND_ROYALFLUSH)
    	{
        sprintf(handnam, "^pRoyal Flush (^k%c^p, ^k%c^p High)",
        		card_suits[handdat->cards[4] % 4], card_symbols[val[0]]);
        }
    else
    	{
        sprintf(handnam, "^pStraight Flush (^k%c^p, ^k%c^p High)",
        		card_suits[handdat->cards[4] % 4], card_symbols[val[0]]);
        }
	}

return handnam;
}
